// LOD_BatchToolWindow.cs
// Unity 2022.3.22f1 compatible
// - Add Apply button (Execute processing)
// - JP/EN UI
// - Options: include children, only existing, add if missing, auto collect renderers into LOD0,
//
//                    delete LOD1+, CrossFade + animateCrossFading
//
// Put this file under an "Editor" folder, e.g.
// Assets/you5248/LOD_BatchTool/Editor/LOD_BatchToolWindow.cs

using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace you5248.LODBatchTool
{
    public class LOD_BatchToolWindow : EditorWindow
    {
        // -------------------------
        // Language
        // -------------------------
        private enum Language
        {
            Japanese,
            English
        }

        // -------------------------
        // LOD cleanup mode
        // -------------------------
        private enum LODCleanupMode
        {
            // Keep LOD0, delete LOD1+
            DeleteLodsKeepLOD0Only,

            // Do nothing to LOD list
            KeepAsIs
        }

        // -------------------------
        // Settings (persistable)
        // -------------------------
        [SerializeField] private Language uiLanguage = Language.Japanese;

        [SerializeField] private bool includeChildren = true;

        // Process only existing LODGroup (if OFF, missing LODGroup can be added depending on addIfMissing)
        [SerializeField] private bool onlyExistingLODGroups = false;

        // Add LODGroup if missing on selected objects (and/or children if includeChildren)
        [SerializeField] private bool addIfMissing = true;

        // When a LODGroup is newly added, auto collect child renderers into LOD0
        [SerializeField] private bool autoCollectChildRenderersToLOD0 = true;

        // If target already has LODGroup, overwrite LOD0 renderer list from child renderers
        [SerializeField] private bool overwriteExistingLOD0Renderers = false;

        [SerializeField] private LODCleanupMode lodCleanupMode = LODCleanupMode.DeleteLodsKeepLOD0Only;

        [SerializeField] private LODFadeMode fadeMode = LODFadeMode.CrossFade;
        [SerializeField] private bool animateCrossFading = true;

        // Exclude ParticleSystemRenderer by default (common for VRC worlds)
        [SerializeField] private bool excludeParticleSystemRenderer = true;

        // When only deleting LODs, we still can apply fade mode etc.
        [SerializeField] private bool applyFadeSettings = true;

        // Safety
        [SerializeField] private bool dryRun = false;

        // Scroll
        private Vector2 scroll;

        // -------------------------
        // Menu
        // -------------------------
        [MenuItem("you5248/LOD Batch Tool")]
        public static void Open()
        {
            var wnd = GetWindow<LOD_BatchToolWindow>();
            wnd.titleContent = new GUIContent("LOD Batch Tool");
            wnd.minSize = new Vector2(520, 420);
            wnd.Show();
        }

        // -------------------------
        // GUI Helpers
        // -------------------------
        private string T(string jp, string en) => uiLanguage == Language.Japanese ? jp : en;

        private void InfoBox(string jp, string en, MessageType type = MessageType.Info)
        {
            EditorGUILayout.HelpBox(T(jp, en), type);
        }

        private void Header(string jp, string en)
        {
            GUILayout.Space(10);
            EditorGUILayout.LabelField(T(jp, en), EditorStyles.boldLabel);
        }

        // -------------------------
        // OnGUI
        // -------------------------
        private void OnGUI()
        {
            scroll = EditorGUILayout.BeginScrollView(scroll);

            // Language
            Header("表示言語", "Language");
            uiLanguage = (Language)EditorGUILayout.EnumPopup(T("表示言語", "Language"), uiLanguage);
            InfoBox(
                "Only updates UI.",
                "This only changes UI text. Processing behavior is identical."
            );

            // Targets
            Header("対象", "Targets");

            includeChildren = EditorGUILayout.ToggleLeft(
                T("子階層も対象", "Include children (process LODGroups under selection)"),
                includeChildren);

            InfoBox(
                "ON: Batch process children LODGroups\nOFF: Process only selected",
                "ON: Process all LODGroups under selected objects.\nOFF: Process only LODGroups directly on selected objects."
            );

            onlyExistingLODGroups = EditorGUILayout.ToggleLeft(
                T("LODGroup を既に持つ対象のみ処理する", "Process only objects that already have LODGroup"),
                onlyExistingLODGroups);

            InfoBox(
                "ON: LODGroup̂ݕҏW܂B\nOFF: LODGroupꍇɒǉIvV܂B",
                "ON: Only edits existing LODGroups.\nOFF: Allows adding LODGroup when missing."
            );

            using (new EditorGUI.DisabledScope(onlyExistingLODGroups))
            {
                addIfMissing = EditorGUILayout.ToggleLeft(
                    T("対象に LODGroup が無い場合は追加する（選択オブジェクトに追加）", "Add LODGroup if missing (to selected objects)"),
                    addIfMissing);

                InfoBox(
                    "If OFF, skips objects without LODGroup\nIf ON, adds LODGroup.",
                    "If OFF, objects without LODGroup will be skipped.\nIf ON, a LODGroup will be added to selected objects."
                );

                using (new EditorGUI.DisabledScope(!addIfMissing))
                {
                    autoCollectChildRenderersToLOD0 = EditorGUILayout.ToggleLeft(
                        T("LODGroup 追加時、子の Renderer を LOD0 に自動収集", "When adding LODGroup, auto-collect child Renderers into LOD0"),
                        autoCollectChildRenderersToLOD0);

                    InfoBox(
                        "Newly added LODGroup will include all child renderers in LOD0.",
                        "When a new LODGroup is added, child Renderers are collected into LOD0.\n(ParticleSystemRenderer is excluded)"
                    );
                }
            }

            // LOD0 Renderer overwrite
            Header("LOD0 の Renderer（任意）", "LOD0 Renderers (Optional)");

            overwriteExistingLOD0Renderers = EditorGUILayout.ToggleLeft(
                T("既存の LODGroup の LOD0 を子の Renderer で上書きする（注意）", "Overwrite existing LOD0 Renderers with child Renderers (CAUTION)"),
                overwriteExistingLOD0Renderers);

            InfoBox(
                "Will replace existing LOD0 if not empty.",
                "If you've manually configured LOD0, this can overwrite it.\nUseful when you want to bulk-fill empty LOD0 renderer lists."
            );

            excludeParticleSystemRenderer = EditorGUILayout.ToggleLeft(
                T("ParticleSystemRenderer を除外する", "Exclude ParticleSystemRenderer"),
                excludeParticleSystemRenderer);

            // LOD1+ handling
            Header("LOD1 以降の扱い", "Handling of LOD1+");

            lodCleanupMode = (LODCleanupMode)EditorGUILayout.EnumPopup(
                T("モード", "Mode"),
                lodCleanupMode);

            switch (lodCleanupMode)
            {
                case LODCleanupMode.DeleteLodsKeepLOD0Only:
                    InfoBox(
                        "Removes LOD1+, resulting in LOD0 -> Culled.",
                        "Keeps only LOD0 and deletes LOD1+.\nResult becomes a 2-stage setup: LOD0 竊ECulled. Lightest and simplest."
                    );
                    break;

                case LODCleanupMode.KeepAsIs:
                    InfoBox(
                        "Will not change LOD structure.",
                        "Does not modify LOD list (but can apply fade settings)."
                    );
                    break;
            }

            // Fade
            Header("フェード（Cross Fade）", "Fade (Cross Fade)");

            applyFadeSettings = EditorGUILayout.ToggleLeft(
                T("フェード設定を適用する", "Apply fade settings"),
                applyFadeSettings);

            using (new EditorGUI.DisabledScope(!applyFadeSettings))
            {
                fadeMode = (LODFadeMode)EditorGUILayout.EnumPopup(
                    T("フェード方式", "Fade Mode"),
                    fadeMode);

                animateCrossFading = EditorGUILayout.ToggleLeft(
                    T("Animate Cross-fading（チェック推奨）", "Animate Cross-fading (recommended)"),
                    animateCrossFading);

                InfoBox(
                    "Crossfade requires material support.",
                    "CrossFade reduces popping when LOD switches.\nCommonly useful in VRChat, but requires shader/material support."
                );
            }

            // Dry run
            Header("セーフティ", "Safety");

            dryRun = EditorGUILayout.ToggleLeft(
                T("Dry Run（実際には変更せずログのみ出力）", "Dry Run (log only, no changes)"),
                dryRun);

            InfoBox(
                "Use for preview. Turn OFF to apply.",
                "Use this to preview how many will be processed. Turn OFF and Apply when ready."
            );

            // Apply
            DrawApplyArea();

            EditorGUILayout.EndScrollView();
        }

        private void DrawApplyArea()
        {
            GUILayout.Space(14);
            EditorGUILayout.LabelField("", GUI.skin.horizontalSlider);

            using (new EditorGUILayout.HorizontalScope())
            {
                GUILayout.FlexibleSpace();

                if (GUILayout.Button(
                    T("選択の再取得", "Refresh Selection"),
                    GUILayout.Width(160),
                    GUILayout.Height(28)))
                {
                    Repaint();
                }

                GUILayout.Space(8);

                var applyLabel = T("選択に適用（Apply）", "Apply to Selection");
                var applyTip = T("選択中のオブジェクトに対して処理を実行します。", "Execute processing for selected objects.");
                if (GUILayout.Button(new GUIContent(applyLabel, applyTip), GUILayout.Width(220), GUILayout.Height(32)))
                {
                    ApplyToSelection();
                }

                GUILayout.FlexibleSpace();
            }

            GUILayout.Space(6);

            // quick status
            var selected = Selection.gameObjects;
            var status = selected != null ? selected.Length : 0;
            EditorGUILayout.LabelField(T($"Selected: {status} object(s)", $"Selected: {status} object(s)"));
        }

        // -------------------------
        // Processing
        // -------------------------
        private void ApplyToSelection()
        {
            var roots = Selection.gameObjects;
            if (roots == null || roots.Length == 0)
            {
                Debug.LogWarning("LOD Batch Tool: No objects selected.");
                return;
            }

            // Build target list
            var lodGroupsToProcess = new List<LODGroup>();
            var targetsNeedingLODGroup = new List<GameObject>();

            foreach (var root in roots)
            {
                if (root == null) continue;

                if (includeChildren)
                {
                    // existing LODGroups under children
                    lodGroupsToProcess.AddRange(root.GetComponentsInChildren<LODGroup>(true));

                    // if adding missing LODGroup: we add only on selected roots (not on every child),
                    // to avoid unexpected additions.
                    if (!onlyExistingLODGroups && addIfMissing)
                    {
                        if (root.GetComponent<LODGroup>() == null)
                            targetsNeedingLODGroup.Add(root);
                    }
                }
                else
                {
                    var lg = root.GetComponent<LODGroup>();
                    if (lg != null) lodGroupsToProcess.Add(lg);

                    if (!onlyExistingLODGroups && addIfMissing && lg == null)
                        targetsNeedingLODGroup.Add(root);
                }
            }

            // Remove duplicates
            Dedup(lodGroupsToProcess);

            // Filter if only existing
            if (onlyExistingLODGroups)
            {
                // No additions.
            }
            else
            {
                // Add LODGroups if requested
                if (addIfMissing && targetsNeedingLODGroup.Count > 0)
                {
                    foreach (var go in targetsNeedingLODGroup)
                    {
                        if (go == null) continue;

                        if (dryRun)
                        {
                            Debug.Log($"[DryRun] Would add LODGroup to: {GetHierarchyPath(go.transform)}");
                            continue;
                        }

                        Undo.AddComponent<LODGroup>(go);
                        var added = go.GetComponent<LODGroup>();
                        if (added != null)
                        {
                            lodGroupsToProcess.Add(added);

                            if (autoCollectChildRenderersToLOD0)
                            {
                                ConfigureLOD0FromChildren(added, go);
                            }
                        }
                    }
                }
            }

            // Process
            Dedup(lodGroupsToProcess);

            int processed = 0;
            int modified = 0;

            foreach (var lodGroup in lodGroupsToProcess)
            {
                if (lodGroup == null) continue;

                processed++;

                if (dryRun)
                {
                    Debug.Log($"[DryRun] Would process LODGroup: {GetHierarchyPath(lodGroup.transform)}");
                    continue;
                }

                Undo.RecordObject(lodGroup, "LOD Batch Tool Apply");

                bool changed = false;

                // Optionally overwrite LOD0 renderers for existing groups
                if (overwriteExistingLOD0Renderers)
                {
                    changed |= ConfigureLOD0FromChildren(lodGroup, lodGroup.gameObject);
                }

                // LOD cleanup
                changed |= ApplyLODCleanup(lodGroup);

                // Fade settings
                if (applyFadeSettings)
                {
                    changed |= ApplyFadeSettings(lodGroup);
                }

                if (changed)
                {
                    lodGroup.RecalculateBounds();
                    EditorUtility.SetDirty(lodGroup);
                    modified++;
                }
            }

            if (dryRun)
            {
                Debug.Log($"LOD Batch Tool [DryRun]: processed {processed} LODGroup(s). No changes were made.");
            }
            else
            {
                Debug.Log($"LOD Batch Tool: processed {processed} LODGroup(s), modified {modified}.");
            }
        }

        private bool ApplyLODCleanup(LODGroup lodGroup)
        {
            bool changed = false;

            var lods = lodGroup.GetLODs();
            if (lods == null || lods.Length == 0)
                return false;

            switch (lodCleanupMode)
            {
                case LODCleanupMode.DeleteLodsKeepLOD0Only:
                {
                    if (lods.Length > 1)
                    {
                        // keep lod0 only
                        var lod0 = lods[0];
                        lodGroup.SetLODs(new[] { lod0 });
                        changed = true;
                    }

                    // Ensure has culled stage by setting last transition height to 0
                    // Note: LODGroup in Unity uses the LOD[] list + "Culled" implicit.
                    // Keeping only LOD0 already results in "LOD0 -> Culled".
                    break;
                }

                case LODCleanupMode.KeepAsIs:
                default:
                    break;
            }

            return changed;
        }

        private bool ApplyFadeSettings(LODGroup lodGroup)
        {
            bool changed = false;

            if (lodGroup.fadeMode != fadeMode)
            {
                lodGroup.fadeMode = fadeMode;
                changed = true;
            }

            if (lodGroup.animateCrossFading != animateCrossFading)
            {
                lodGroup.animateCrossFading = animateCrossFading;
                changed = true;
            }

            return changed;
        }

        /// <summary>
        /// Set LOD0 renderers to child renderers under root.
        /// Excludes ParticleSystemRenderer if configured.
        /// Keeps LOD0 screenRelativeTransitionHeight as-is (only changes renderer list).
        /// </summary>
        private bool ConfigureLOD0FromChildren(LODGroup lodGroup, GameObject root)
        {
            if (lodGroup == null || root == null) return false;

            var lods = lodGroup.GetLODs();
            if (lods == null || lods.Length == 0)
            {
                // Create a default LOD0 if none exists
                lods = new[] { new LOD(0.6f, Array.Empty<Renderer>()) };
            }

            var renderers = CollectChildRenderers(root.transform, excludeParticleSystemRenderer);

            // If nothing collected, do nothing
            if (renderers.Count == 0) return false;

            // Compare with existing
            var old = lods[0].renderers ?? Array.Empty<Renderer>();
            bool different = !SameRendererSet(old, renderers);

            if (!different) return false;

            lods[0] = new LOD(lods[0].screenRelativeTransitionHeight, renderers.ToArray());
            lodGroup.SetLODs(lods);
            return true;
        }

        private List<Renderer> CollectChildRenderers(Transform root, bool excludePSR)
        {
            var list = new List<Renderer>();
            if (root == null) return list;

            // include inactive
            var renderers = root.GetComponentsInChildren<Renderer>(true);
            foreach (var r in renderers)
            {
                if (r == null) continue;

                // Exclude the renderer on the root LODGroup itself? (No, we should include if it is a MeshRenderer)
                if (excludePSR && r is ParticleSystemRenderer) continue;

                // Typical: Skip disabled renderers? For LOD, disabled renderers are usually not desired.
                // But user might want them included. We'll keep them included to be consistent with hierarchy.
                list.Add(r);
            }

            return list;
        }

        private static bool SameRendererSet(Renderer[] oldSet, List<Renderer> newSet)
        {
            if (oldSet == null) oldSet = Array.Empty<Renderer>();
            if (newSet == null) newSet = new List<Renderer>();

            if (oldSet.Length != newSet.Count) return false;

            var hs = new HashSet<Renderer>(oldSet);
            for (int i = 0; i < newSet.Count; i++)
            {
                if (!hs.Contains(newSet[i])) return false;
            }
            return true;
        }

        private static void Dedup(List<LODGroup> list)
        {
            var hs = new HashSet<LODGroup>();
            for (int i = list.Count - 1; i >= 0; i--)
            {
                var v = list[i];
                if (v == null || !hs.Add(v))
                    list.RemoveAt(i);
            }
        }

        private static string GetHierarchyPath(Transform t)
        {
            if (t == null) return "<null>";
            var stack = new Stack<string>();
            while (t != null)
            {
                stack.Push(t.name);
                t = t.parent;
            }
            return string.Join("/", stack);
        }
    }
}

